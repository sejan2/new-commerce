const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../../models/User");

const registerUser = async (req, res) => {
  const { userName, email, password } = req.body;
  try {
    const checkUser = await User.findOne({ email });
    if (checkUser)
      return res.json({
        success: false,
        message: "User already exists with the same email! Please try again",
      });

    const hashPassword = await bcrypt.hash(password, 12);
    const newUser = new User({ userName, email, password: hashPassword });
    await newUser.save();

    res.status(200).json({ success: true, message: "Registration successful" });
  } catch (e) {
    res.status(500).json({ success: false, message: "Some error occurred" });
  }
};

const loginUser = async (req, res) => {
  const { email, password } = req.body;
  try {
    const checkUser = await User.findOne({ email });
    if (!checkUser)
      return res.json({
        success: false,
        message: "User doesn't exist! Please register first",
      });

    const checkPasswordMatch = await bcrypt.compare(password, checkUser.password);
    if (!checkPasswordMatch)
      return res.json({ success: false, message: "Incorrect password! Please try again" });

    const token = jwt.sign(
      { id: checkUser._id, role: checkUser.role, email: checkUser.email, userName: checkUser.userName },
      process.env.JWT_SECRET || "fallback_secret_change_me",
      { expiresIn: "60m" }
    );

    // ✅ Fix - secure must be true in production (HTTPS)
res.cookie("token", token, {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
}).json({
      success: true,
      message: "Logged in successfully",
      user: { email: checkUser.email, role: checkUser.role, id: checkUser._id, userName: checkUser.userName },
    });
  } catch (e) {
    res.status(500).json({ success: false, message: "Some error occurred" });
  }
};

const logoutUser = (req, res) => {
  res.clearCookie("token").json({ success: true, message: "Logged out successfully!" });
};

const authMiddleware = async (req, res, next) => {
  const token = req.cookies.token;
  if (!token)
    return res.status(401).json({ success: false, message: "Unauthorised user!" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "fallback_secret_change_me");
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ success: false, message: "Unauthorised user!" });
  }
};

module.exports = { registerUser, loginUser, logoutUser, authMiddleware };
